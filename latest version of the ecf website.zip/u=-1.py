u=-1
for i in range (7):
    u=3*u-4
print(u)
